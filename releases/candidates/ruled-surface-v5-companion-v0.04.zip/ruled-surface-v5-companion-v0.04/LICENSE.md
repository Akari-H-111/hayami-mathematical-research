# License

Copyright 2026 Akari Hayami (Jian-Yu Huang).

- Lean and Python source, including the formalization, verification and figure
  tools, is licensed under the Apache License, Version 2.0 (`Apache-2.0`):
  <https://www.apache.org/licenses/LICENSE-2.0>.
- Documentation, notes, figures, metadata and original research material are
  licensed under the Creative Commons Attribution 4.0 International License
  (`CC-BY-4.0`): <https://creativecommons.org/licenses/by/4.0/legalcode>.

Third-party dependencies (Lean, Mathlib and their dependencies, Python
libraries) retain their own licenses. Earlier sealed packages are unchanged.
