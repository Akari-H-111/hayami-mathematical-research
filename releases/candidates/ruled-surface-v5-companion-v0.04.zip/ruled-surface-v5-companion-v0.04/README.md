# Ruled surface v5 verification companion — version 0.04

Akari Hayami (Jian-Yu Huang), 2026-10-17. Source-only software package; no PDF of a published paper
is redistributed.

New in v0.04 (research beyond the published article): the global
self-intersection of the surface S(t,u) = (c + 2u(1-c), (1-u) sin t, u sqrt(c(2-c)))
on the closed rectangle is classified. Distinct labels share an image exactly
on the u = 1 seam or on two mirror double arcs; each arc's source closure runs
from the edge label (+-pi/2, 2/5) through the interior cross-cap to the base
label (+-arccos(4/5), 0), and the common image starts at (4/5, +-3/5, 0). The
quotient double curve has an explicit rational parametrization.

Lean (`RuledV5/SelfIntersection.lean`, `DoubleFamily.lean`,
`DoubleNormalization.lean`) proves, for the actual surface: the seam iff,
mirror-half separation, the exact boundary double points, the universal
elimination certificate, sufficiency of the explicit family for every
0 <= v < sqrt 5 - 2 with its actual image, and the converse in each open
angular half (two distinct labels with equal images are exactly the explicit
pair for a unique v). The closed-rectangle assembly, global two-label bound,
cross-cap singleton fibers, smoothness of the source arcs and the quotient
homeomorphism are written proofs in
`papers/legacy-geometry/orthogonal-circle-ruled-surface/notes/SELF_INTERSECTION.md`.
The exceptional germ is classified in the Stokes companion v0.05.

All 246 public named RuledV5 theorems and the 268 StokesV5 dependency
theorems pass build, status, exhaustive axiom audit and proof-hole scan; the
two inventories are separate. The article is not Lean-formalized as a whole;
see `companions/lean/ruled-surface-v5/COVERAGE.md`.

Lean inventories (each audited separately; counts are not whole-paper coverage):

- RuledV5: 246 public named theorems
- StokesV5 (dependency): 268 public named theorems

## Replay

Requires Lean 4.33.1 via elan/Lake (Mathlib v4.33.1 is pinned in the lockfiles;
do not run `lake update`) and a Python 3 environment with
`requirements.txt`. From this directory:

```sh
python3 -B verify.py
```

`verify.py` checks every payload hash, runs `verify_lean.py` in each Lean
project in dependency order (fetching the pinned Mathlib build cache with
`lake exe cache get` when absent) and runs the exact Python verifiers. Never
use Python `-O`: the verifiers rely on assertions.

## Citation

Cite the paper(s) (10.5281/zenodo.23073642) and this software version separately.
All-version software concept DOI: `10.5281/zenodo.23073653`. Previous version:
v0.03, software DOI 10.5281/zenodo.23073654. Repository:
<https://github.com/Akari-H-111/hayami-mathematical-research>, release tag
`ruled-surface-v5-companion-v0.04`, built from commit `8a6f9140fdc0731a071d7c4a2c1fbd67162e7ae3`.

Code: Apache-2.0. Documentation, notes and figures: CC-BY-4.0. See `LICENSE.md`.
