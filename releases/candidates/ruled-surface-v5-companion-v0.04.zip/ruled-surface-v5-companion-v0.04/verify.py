"""Fail-closed replay of this package. Never run with python -O."""
from pathlib import Path
import hashlib
import subprocess
import sys

assert not sys.flags.optimize, "verifiers rely on assertions"
ROOT = Path(__file__).resolve().parent
LEAN = ['companions/lean/stokes-caustic-v5', 'companions/lean/ruled-surface-v5']
PYTHON = ['papers/legacy-geometry/orthogonal-circle-ruled-surface/verification/verify_self_intersection.py']


def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, text=True, errors="replace",
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(f"FAIL: {' '.join(command)} in {cwd}")
    return result.stdout


def main():
    manifest = ROOT / "SHA256SUMS.txt"
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise SystemExit(f"FAIL payload hash: {name}")
    print("PASS payload hashes", flush=True)
    for project in LEAN:
        directory = ROOT / project
        if not (directory / ".lake" / "packages" / "mathlib").exists():
            run(["lake", "exe", "cache", "get"], directory)
        print(run([sys.executable, "-B", "verify_lean.py"], directory).strip().splitlines()[-1],
              f"[{project}]", flush=True)
    for script in PYTHON:
        print(run([sys.executable, "-B", str(ROOT / script)], ROOT).strip().splitlines()[-1],
              f"[{script}]", flush=True)
    print("PASS complete package replay", flush=True)


if __name__ == "__main__":
    main()
