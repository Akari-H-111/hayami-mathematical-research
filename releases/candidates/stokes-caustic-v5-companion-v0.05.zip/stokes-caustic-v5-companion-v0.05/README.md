# Stokes caustic v5 Lean companion — version 0.05

Akari Hayami (Jian-Yu Huang), 2026-10-17. Source-only software package; no PDF of a published paper
is redistributed.

New in v0.05 (research beyond the published paper): the exceptional
point (t,u) = (0,0) of the observation map is fully classified. The map
factors as F(t,u) = G(cos t, u), where G is an ordinary Whitney fold at (1,0)
whose kernel and critical curve are transverse to the ramification line c = 1.
Lean (`StokesV5/ExceptionalNormalForm.lean`) constructs actual smooth
two-sided source and target charts taking the actual observation map to
(X, X y^2 + y^4) near the exceptional point, with a source chart that
intertwines t -> -t and y -> -y (`exceptional_hasFoldOfFoldNormalFormAt`,
`exceptional_equivariant_charts`), and proves the quotient fold
(`quotient_hasWhitneyNormalFormAt`). The proof note
`papers/legacy-geometry/stokes-caustic/notes/EXCEPTIONAL_GERM.md` (with five
reproducible figures) adds written results: the real-analytic version,
non-finite A-determinacy (via Moya-Perez and Nuno-Ballesteros 2020,
Cor. 2.2(3)), recentred persistence under even perturbations, the labels
11_(2k+1) for odd perturbations (checked in Kabata 2016), and the absence of a
finite-parameter marked versal unfolding for the restricted odd-quotient class
at the even base. A versal family at a selected 11_5 member remains open.

All 268 public named StokesV5 theorems pass build, status, exhaustive axiom
audit (only propext, Classical.choice, Quot.sound) and the proof-hole scan.
The published paper is not Lean-formalized as a whole; the statement-level
coverage map is `companions/lean/stokes-caustic-v5/FULL_PAPER_COVERAGE.md`.

Lean inventories (each audited separately; counts are not whole-paper coverage):

- StokesV5: 268 public named theorems

## Replay

Requires Lean 4.33.1 via elan/Lake (Mathlib v4.33.1 is pinned in the lockfiles;
do not run `lake update`) and a Python 3 environment with
`requirements.txt`. From this directory:

```sh
python3 -B verify.py
```

`verify.py` checks every payload hash, runs `verify_lean.py` in each Lean
project in dependency order (fetching the pinned Mathlib build cache with
`lake exe cache get` when absent) and runs the exact Python verifiers. Never
use Python `-O`: the verifiers rely on assertions.

## Citation

Cite the paper(s) (10.5281/zenodo.22728902) and this software version separately.
All-version software concept DOI: `10.5281/zenodo.22726976`. Previous version:
v0.04, software DOI 10.5281/zenodo.23057630. Repository:
<https://github.com/Akari-H-111/hayami-mathematical-research>, release tag
`stokes-v5-companion-v0.05`, built from commit `8a6f9140fdc0731a071d7c4a2c1fbd67162e7ae3`.

Code: Apache-2.0. Documentation, notes and figures: CC-BY-4.0. See `LICENSE.md`.
