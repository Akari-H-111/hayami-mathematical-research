# Verification Companion for Realization Limits and Pseudo-Laplacians at Whitney Cross-Caps — version 1.1

Akari Hayami (Jian-Yu Huang), 2026-10-17. Source-only software package; no PDF of a published paper
is redistributed except the two historical Bicomplex PDFs carried over from 1.0.

New in 1.1: the Lean project now gives partial coverage of 105 selected
statements of the two published successor papers (1.0: 33). Eleven new
modules formalize, on the actual objects and with the papers' hypotheses:
the endpoint obstructions and the affine/Bloch no-go (Paper 1, prop:twoobs),
phase-invariant and density-matrix readouts (prop:gauge), analytic curves and
readout rigidity (lem:analytic, thm:rigidity part 1), the log-scale and
linear-scale windows (prop:windows), the Roman surface tangent rank and
normalized Whitney jets (Paper 2, prop:roman), the signed-permutation pair
orbits and invariant matrix form (thm:romanB, finite part), the
reference-length shear and Friedrichs plane (cor:scale), and the model
logarithmic cutoff energy (prop:capacity, scalar core). Two precision notes
are recorded in COVERAGE.md: the printed window bound needs delta != 0, and
the Roman multiplicities 1, 2, 3 are block dimensions. Operator/PDE results,
the analytic construction of B_eta and Whitney recognition remain written or
external; neither paper is Lean-formalized.

Unlike 1.0, this package includes the sibling RuledV5 and StokesV5 projects,
so it builds on its own. All three inventories pass build, status,
exhaustive axiom audit and proof-hole scan separately.

Lean inventories (each audited separately; counts are not whole-paper coverage):

- Bicomplex: 105 public named theorems
- RuledV5 (dependency): 246 public named theorems
- StokesV5 (dependency): 268 public named theorems

## Replay

Requires Lean 4.33.1 via elan/Lake (Mathlib v4.33.1 is pinned in the lockfiles;
do not run `lake update`) and a Python 3 environment with
`requirements.txt`. From this directory:

```sh
python3 -B verify.py
```

`verify.py` checks every payload hash, runs `verify_lean.py` in each Lean
project in dependency order (fetching the pinned Mathlib build cache with
`lake exe cache get` when absent) and runs the exact Python verifiers. Never
use Python `-O`: the verifiers rely on assertions.

## Citation

Cite the paper(s) (10.5281/zenodo.23103026 (paper 1) and 10.5281/zenodo.23103056 (paper 2)) and this software version separately.
All-version software concept DOI: `10.5281/zenodo.23103298`. Previous version:
1.0, software DOI 10.5281/zenodo.23103299. Repository:
<https://github.com/Akari-H-111/hayami-mathematical-research>, release tag
`bicomplex-successor-v1.1`, built from commit `8a6f9140fdc0731a071d7c4a2c1fbd67162e7ae3`.

Code: Apache-2.0. Documentation, notes and figures: CC-BY-4.0. See `LICENSE.md`.
