"""Run the two successor verifiers (which replay the earlier exact verifiers)."""
from pathlib import Path
import subprocess
import sys

V = Path(__file__).resolve().parent / "papers/legacy-geometry/bicomplex-signal-manifolds/verification"


def main():
    assert not sys.flags.optimize
    for name in ("verify_successor_paper1.py", "verify_successor_paper2.py"):
        result = subprocess.run([sys.executable, "-B", str(V / name)], text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        print(result.stdout, end="")
        if result.returncode:
            raise SystemExit(f"FAIL {name}")
    print("PASS all successor verifiers")


if __name__ == "__main__":
    main()
