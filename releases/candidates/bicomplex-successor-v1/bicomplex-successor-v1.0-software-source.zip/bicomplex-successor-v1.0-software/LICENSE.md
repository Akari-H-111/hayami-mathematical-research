# License policy

Copyright 2026 Akari Hayami (Jian-Yu Huang).

This package uses a mixed license determined by file type.

## Software

Lean (`.lean`) and Python (`.py`) source code, with executable build and
verification configuration (`lakefile.toml`, `lake-manifest.json`,
`lean-toolchain`, `requirements.txt`), is licensed under the Apache License,
Version 2.0 (`Apache-2.0`): <https://www.apache.org/licenses/LICENSE-2.0>.
Unless required by applicable law or agreed to in writing, software distributed
under this license is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied.

## Scholarly and documentation material

The two article TeX sources, original figures, Markdown documentation, claim
maps and citation metadata are licensed under the Creative Commons Attribution
4.0 International License (`CC-BY-4.0`):
<https://creativecommons.org/licenses/by/4.0/legalcode>.

## Third-party and historical material

`papers/legacy-geometry/source-registry/` holds two earlier public files of the
author (v11, v12), included only so that their SHA-256 hashes can be replayed,
and `source_ancestor/` holds the author's earlier TeX source; both are covered
by CC-BY-4.0 as the author's own material. Third-party dependencies (Lean,
Mathlib, Python packages) keep their own licenses.

When a file contains a more specific license notice, that notice controls.
