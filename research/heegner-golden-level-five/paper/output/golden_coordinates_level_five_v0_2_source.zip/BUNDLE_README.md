# Source bundle — Golden Coordinates at Level Five, portrait revision 0.2

Author: Akari Hayami (Jian-Yu Huang)  
Contact: akari.h.1.9984@gmail.com  
Date: 20 October 2026

This bundle contains the article source, the visual companion builder and
plates, the four compact body figures, saved plotting data, exact/numerical
checkers, and the verification records for portrait revision 0.2. It is a local
draft: no commit, upload, or publication is included or implied.

## Contents

- `paper-v0.2-portrait-20261020/main.tex` — 10-page Letter article.
- `paper-v0.2-portrait-20261020/output/pdf/` — compiled article and 14-page
  supplement.
- `paper-v0.2-portrait-20261020/companion/` — plate and body-figure sources,
  data, plotting scripts, and data checkers.
- `paper-v0.2-portrait-20261020/build_companion.py` — supplement assembler.
- `paper-v0.2-portrait-20261020/verification/` — exact checkers, layout check,
  visual-QA hashes, preservation check, and the Davenport–Heilbronn check.
- `paper-v0.2-portrait-20261020/provenance/` — client model selections, the
  pre-polish source, and the final compile log.
- `paper-v0.2-portrait-20261020/input/` — frozen surface source and context.
- `BUNDLE_SHA256.json` — SHA-256 for every file in this bundle except itself.

The article's README, claim map, assembly notes, and director resolution give
the full reading order and evidence separation. The extraction-rebuild record is
kept in the working packet at `verification/REBUILD_CHECK.json`, outside this
zip, because it hashes the zip itself.

## Rebuild

From `paper-v0.2-portrait-20261020/`:

```sh
mkdir -p output/pdf
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error \
  -jobname=golden_coordinates_level_five_v0_2 -output-directory=output/pdf main.tex
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error \
  -jobname=golden_coordinates_level_five_v0_2 -output-directory=output/pdf main.tex
qpdf --check output/pdf/golden_coordinates_level_five_v0_2.pdf
LAYOUT_LOG=output/pdf/golden_coordinates_level_five_v0_2.log \
  /Users/akari_hayami_64/RH_Research_Workspace/.venv/bin/python -B verification/check_final_pdf.py
```

The supplement is already included. To rebuild it, run:

```sh
/Users/akari_hayami_64/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  -B build_companion.py
```

The supplement needs ReportLab and pypdf. The figure scripts need the recorded
Matplotlib environment. Equivalent interpreters with those dependencies should
work; this bundle does not install them. Never run the checkers with Python `-O`.

## Scope

Exact certificates, written analytic proofs, and finite numerical diagnostics
are separate evidence classes. The CM/Klein, modular-inversion, and Poisson
inputs retain their citations. The conductor-815 field is attributed to
Spearman–Williams. No Riemann-hypothesis result, Lean formalization, novelty
priority, or journal acceptance is claimed. The HMR/RH bridge is secondary.
