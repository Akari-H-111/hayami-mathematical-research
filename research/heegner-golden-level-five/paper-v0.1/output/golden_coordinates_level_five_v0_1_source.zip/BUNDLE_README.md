# Golden Coordinates at Level Five — first-draft source bundle

Author: Akari Hayami (Jian-Yu Huang)
Contact: akari.h.1.9984@gmail.com
Assembled 20 October 2026.

Keep the two sibling directories together. Start with paper-v0.1-20261019/README.md
and its main.tex. The included twelve cropped figures suffice to compile the
19-page paper. The other directory contains plotting source, data, original
vector plates, SVG/PNG exports and the 14-page figure atlas. Each packet has an
AUTHORED_SHA256.json; BUNDLE_SHA256.json binds all archived files except itself.

Existing local interpreter paths in replay instructions identify the tested
runtimes. Use equivalent environments on another machine; no installer or
clean-machine dependency setup is included. Mathematical diagnostics and written
proofs are distinguished in PAPER_CLAIM_MAP.md. DeepSeek review files are raw
proposals and contain corrected errors: consult DIRECTOR_ADVICE_RESOLUTION.md.

This is a local first draft, not a publication or external peer-review receipt.
